package listtype

// +k8s:openapi-gen=true
type UntypedList struct {
	Field []string
}
