Auto-generated logging v2 clients
=================================

This package includes auto-generated clients for the logging v2 API.

Use the handwritten logging client (in the parent directory,
cloud.google.com/go/logging) in preference to this.

This code is EXPERIMENTAL and subject to CHANGE AT ANY TIME.


